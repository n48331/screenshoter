$(document).ready(function () {
    var activeItem = localStorage.getItem(app.var.project + "sub_slide");
    if (activeItem != null && activeItem != '') {

        $('.item').removeClass('active');
        $('.item:nth-child(' + activeItem + ')').addClass('active');
        setTimeout(function () {
            localStorage.setItem(app.var.project + "sub_slide", '');
        }, 100);
    }
    else {
        $('.item:nth-child(1)').addClass('active');
    }
    var goToHome = localStorage.getItem("goToPrev");
    app.Checksub_slide_localstorage(goToHome);
}); 